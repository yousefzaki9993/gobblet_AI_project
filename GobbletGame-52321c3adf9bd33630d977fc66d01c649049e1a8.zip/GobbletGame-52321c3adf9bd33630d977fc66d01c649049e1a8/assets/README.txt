this folder containes the needed assets for the game
