# GobbletGame
implementation of the well-known gobblet as a desktop application in various modes of playing
