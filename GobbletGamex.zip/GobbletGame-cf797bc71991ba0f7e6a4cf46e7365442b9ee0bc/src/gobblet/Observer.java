package gobblet;

public interface Observer {
	boolean isBlack();
    void startRole();
    void endGame();
}
