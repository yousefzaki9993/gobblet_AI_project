package gobblet;

public interface ScoreEval
{
    public int evaluateBoard(boolean colorScores);
    
}
